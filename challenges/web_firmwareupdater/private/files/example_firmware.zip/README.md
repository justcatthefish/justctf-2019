Make sure you agree with firmware privacy policy.
Backup data before update!